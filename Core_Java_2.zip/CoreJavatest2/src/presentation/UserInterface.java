package presentation;

import businesslogic.CallDetailsPresenter;
import businesslogic.InvoiceGenerator;
import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		CallDetailsPresenter detailsPresenter = new CallDetailsPresenter();
		InvoiceGenerator invoiceGenerator = new InvoiceGenerator();

		System.out.println("Welcome to Telecom Billing System");
		System.out.println("Enter your choice:");
		System.out.println("1. View Call Details");
		System.out.println("2. Generate Invoice");

		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Displaying Call Details.....");
			detailsPresenter.displayCallDetails("12345");
			break;
		case 2:
			System.out.println("Generating Invoice.....");

			invoiceGenerator.generateInvoice("12345", 57.0);
			break;
		default:
			System.out.println("Invalid choice.");
		}
	}

}
