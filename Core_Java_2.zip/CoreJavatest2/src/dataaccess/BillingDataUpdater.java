package dataaccess;

public class BillingDataUpdater {
	public void updateBillingData(String userId, double amount) {
		System.out.println("Billing data updated for User " + userId + " with amount $" + amount);
	}

}
