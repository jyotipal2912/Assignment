package dataaccess;

import java.util.List;

public class CallRecordFetcher {
	public List<String> fetchCallRecords(String userId) {
		return List.of("Call Record 1 for User " + userId, "Call Record 2 for User " + userId);
	}

}
