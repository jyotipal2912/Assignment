module CoreJavatest2 {
}