package businesslogic;
import dataaccess.BillingDataUpdater;

public class InvoiceGenerator {
	private BillingDataUpdater updater = new BillingDataUpdater();

    public void generateInvoice(String userId, double callCharges) {
        // Here you would apply any discounts or additional charges
        double finalAmount = callCharges; // Placeholder calculation
        updater.updateBillingData(userId, finalAmount);
        System.out.println("Invoice generated for User " + userId + ": $" + finalAmount);
    }
}
