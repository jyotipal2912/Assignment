package businesslogic;

import dataaccess.CallRecordFetcher;
import java.util.List;

public class CallDetailsPresenter {
	private CallRecordFetcher fetcher = new CallRecordFetcher();

	public void displayCallDetails(String userId) {
		List<String> callDetails = fetcher.fetchCallRecords(userId);
		callDetails.forEach(System.out::println);
	}

}
