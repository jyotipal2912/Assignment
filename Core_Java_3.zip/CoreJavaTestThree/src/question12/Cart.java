package question12;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Scanner;

public class Cart {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter type of collection : ");
		String collectionType = sc.nextLine();
		Collection<Items> cart;
		switch (collectionType) {
		case "ArrayList":
			cart = new ArrayList<>();
			break;
		case "HashSet":
			cart = new HashSet<>();
			break;
		default:
			System.out.println("Invalid collection type. Exiting....");
			return;
		}
		System.out.println("Enter item details (name price quantity), One item per line: ");
		String line;
		while (!(line = sc.nextLine()).isEmpty()) {
			String[] parts = line.split(" ");
			String name = parts[0];
			double price = Double.parseDouble(parts[1]);
			int quantity = Integer.parseInt(parts[2]);
			cart.add(new Items(name, price, quantity));

		}
		double total = 0;
		for (Items items : cart) {
			System.out.printf("  %s (%d x $%.2f) - $%.2f\n", items.getName(), items.getQuantity(), items.getPrice(),
					items.getTotalCost());
			total += items.getTotalCost();
		}
		System.out.printf("Total Price: $%.2f\n", total);
		if (total > 100) {
			double discount = total * 0.10;
			System.out.printf("Discount (10%%): $%.2f\n", discount);
			total -= discount;
		}
		System.out.printf("Final Price: $%.2f\n", total);

	}

}
