package question3;

public class CloudStorageService implements DigitalService {

	@Override
	public void login(String username, String password) {
		System.out.println("Logged in to Cloud Storage Service with username: " + username);
	}

	@Override
	public void logout() {
		System.out.println("Logged out from Cloud Storage Service.");
	}

	@Override
	public void accessContent(String contentId) {
		System.out.println("Accessing file with ID: " + contentId + " in Cloud Storage Service.");
	}

	@Override
	public void updateProfile(String firstName, String lastName, String email) {
		System.out.println("Profile updated on Cloud Storage Service for: " + firstName + " " + lastName);
	}
}
