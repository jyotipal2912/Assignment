module CoreJavatest3 {
}