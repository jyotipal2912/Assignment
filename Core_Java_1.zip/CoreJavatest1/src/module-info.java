module CoreJavatest1 {
}