package corejava;

class InvalidRentalPeriodException extends Exception {
	public InvalidRentalPeriodException(String message) {
		super(message);
	}
}