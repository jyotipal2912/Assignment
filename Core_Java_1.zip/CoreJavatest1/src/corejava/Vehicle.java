package corejava;

import java.util.List;
import java.util.ArrayList;

class Vehicle {
	String id, type;
	boolean available;
	int availableDays;

	public Vehicle(String id, String type, boolean available, int availableDays) {
		this.id = id;
		this.type = type;
		this.available = available;
		this.availableDays = availableDays;
	}
}