package corejava;

class RentalRequest {
	String vehicleType;
	int rentalPeriod;

	public RentalRequest(String vehicleType, int rentalPeriod) {
		this.vehicleType = vehicleType;
		this.rentalPeriod = rentalPeriod;
	}
}
